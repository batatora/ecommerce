@extends('layouts.admin')

@section('content')

<div class="content-area">
              <div class="mr-breadcrumb">
                <div class="row">
                  <div class="col-lg-12">
                      <h4 class="heading">Product Limit</h4>
                    <ul class="links">
                      <li>
                        <a href="{{ route('admin.dashboard') }}">{{ __('Dashboard') }} </a>
                      </li>
                      <li>
                        <a href="javascript:;">{{ __('General Settings') }}</a>
                      </li>
                      <li>
                        <a href="javascript:;">Product Limit</a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
              @if(\Session::has('msg'))
                <div class="alert alert-success">
                  {{ \Session::get('msg') }}
                </div>
              @endif
              <div class="add-product-content1">
                <div class="row">
                  <div class="col-lg-12">
                    <div class="product-description">
                      <div class="body-area">
                        <div class="gocover" style="background: url({{asset('assets/images/'.$gs->admin_loader)}}) no-repeat scroll center center rgba(45, 45, 45, 0.5);"></div>
                        @include('includes.admin.form-both')  
                            <form action="{{ route('admin.product.limit') }}" method="post">
                        <div class="row justify-content-center">
                            <div class="col-lg-3 pt-2">
                              <div class="left-area">
                                <h4 class="heading">
                                    Product Limit
                                </h4>
                              </div>
                            </div>
                            {{ csrf_field() }}
                              <div class="col-lg-6">
                                  <div class="action-list">
                                      <select id="limit" name="limittype">
                                        <option value="1" {{ $data->productlimit != 'unlimited'?'selected':''}}>Limited</option>
                                        <option value="2" {{ $data->productlimit == 'unlimited'?'selected':''}} >Unlimited</option>
                                      </select>
                                        <div id="field" class="form-group">
                                        <input type="number" name="plimit" class="form-control" value="{{ isset($data->productlimit)?$data->productlimit:'' }}">
                                      </div>
                                  </div>
                                  <button class="addProductSubmit-btn" type="submit">{{ __('Save') }}</button>
                              </div>
                            </form>
                          </div>
                          <div class="row justify-content-center"></div>
                        <div class="row justify-content-center">
                          <div class="col-lg-3">
                            <div class="left-area">
                            </div>
                          </div>
                          <div class="col-lg-6">
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
@endsection